// let nombre = 'Wolverine';

// if (true) {
//     let nombre = 'Magento';
// }


// console.log(nombre);

let i = 'Hola Mundo';

for (let i = 0; i <= 5; i++) {
    console.log(`i: ${ i }`);
}

console.log(i);